import numpy as np, pandas as pd, snap, math, os, time
from scipy.stats import norm
from scipy import spatial, sparse
from estimation_module import *
from gen_net_module import *

####### CREATE OUTPUT DIRECTORIES #######

if not os.path.exists('output'):
    os.makedirs('output')
os.chdir('output')

for directory in ['id_set', 'moments', 'sim_nets', 'stats']:
    if not os.path.exists(directory):
        os.makedirs(directory)
 
####### MAIN #######

seed = 1
np.random.seed(seed=seed)

d = 2 # dimension of RGG. to change to d != 2, see description of gen_r() in
      # gen_net_module
N = 5000 # number of nodes
B = 10 # number of simulations
estimate_r = True # set to false to run simulations with r known

# true parameter: intercept, homophily, transitivity, variance of random utility
theta = np.array([0.2, -0.2, 0.2, 0.8])

for b in range(B):

    ####### GENERATE NETWORKS #######

    # positions uniformly distributed on unit cube
    positions = np.random.uniform(0,1,(N,d))
    # binary homophilous attribute
    Z = np.random.binomial(1, 0.35, N)
    # random utility terms
    eps = sparse.triu(np.random.normal(0, math.sqrt(theta[3]), (N,N)), 1)
    # V minus endogenous statistic
    V_exo = gen_V_exo(Z, eps, theta)
    
    # generate random graphs 
    (r, kappa) = gen_r(theta, d, N)
    RGG = gen_RGG(positions, r) # initial RGG
    (D, RGG_minus, RGG_exo) = gen_D(RGG, V_exo, theta[2])
    # generate pairwise-stable network
    G = gen_G(D, RGG_minus, RGG_exo, V_exo, theta[2], N)

    # save output
    snap.SaveEdgeList(G, \
            'sim_nets/simG_N_' + str(N) + '_b_' + str(b) + '.edgelist')
    pd.DataFrame(positions).to_csv(
            'sim_nets/simRhos_N_' + str(N) + '_b_' + str(b) + '.csv', \
            index=False, header=False)
    pd.DataFrame(Z).to_csv(
            'sim_nets/simZ_N_' + str(N) + '_b_' + str(b) + '.csv', \
            index=False, header=False)
    pd.DataFrame([kappa]).to_csv(
            'sim_nets/simK_N_' + str(N) + '_b_' + str(b) + '.csv', \
            index=False, header=False)
    
    # summary statistics
    graph_sumstats(G, 'G', 'stats/statsG_' + str(N) + '_b_' + str(b) + '.txt', \
            Z, True)
    graph_sumstats(D, 'D', 'stats/statsD_' + str(N) + '_b_' + str(b) + '.txt', \
            Z, False)
    graph_sumstats(RGG, 'RGG', 'stats/statsR_' + str(N) + '_b_' + str(b) + '.txt', \
            Z, False)
    graph_sumstats(RGG_exo, \
            'RGG_exo', 'stats/statsRexo_' + str(N) + '_b_' + str(b) + '.txt', \
            Z, False)

    # verify pairwise stability
    if not check_pw(G, RGG, V_exo, theta[2]):
        raise ValueError('Simulation ' + str(b) + ' is not pairwise stable.')
    
    ####### ESTIMATION #######
    
    # estimate r
    if estimate_r:
        r = gen_rhat(G, positions)
        pd.DataFrame([r]).to_csv('sim_nets/rhat_N_' + str(N) + '_b_' + \
                str(b) + '.csv', index=False, header=False)
        RGG = gen_RGG(positions, r) 

    # estimate identified set
    # Note: this is not efficient code. Estimation takes around 3 hours for N =
    # 1000 and a day for N = 5000.
    (observed_moment, model_moments_grid, id_set) = grid_search(G, RGG, Z, 11)
    
    # save output
    pd.DataFrame(id_set).to_csv(
            'id_set/id_set_N_' + str(N) + '_b_' + str(b) + '.csv', \
            index=False, header=False)
    pd.DataFrame(observed_moment).to_csv(
            'moments/observed_moment_N_' + str(N) + '_b_' + str(b) + '.csv', \
            index=False, header=False)
    pd.DataFrame(model_moments_grid).to_csv(
            'moments/model_moments_grid_N_' + str(N) + '_b_' + str(b) + '.csv', \
                    index=False, header=False)

