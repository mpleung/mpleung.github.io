import numpy as np, pandas as pd, snap, os, math, time
from scipy.stats import norm

def gen_rhat(G, positions):
    """
    Returns estimate of RGG linking threshold = max{||i-j||: G_{ij}=1}. See
    Remark 5.

    G = pairwise-stable network on N nodes (snap object, output of gen_G() in
    gen_net_module).
    positions = Nx2 matrix of node positions in R^2.
    """
    output = 0
    for edge in G.Edges():
        i = edge.GetSrcNId()
        j = edge.GetDstNId()
        dist = math.sqrt((positions[i,0] - positions[j,0])**2 + \
                (positions[i,1] - positions[j,1])**2)
        output = max(output, dist)
    return output

def gen_observed_moment(G, Pi, Z):
    """
    Implements estimator (26).
    
    Returns 2x4 matrix. Each row is the 1x4 vector 1/n \sum_{i,j}
    \mathbf{Y}_{ij}(r_n) h(X_{ij}) corresponding respectively to the instruments
    1{Z_i = Z_j} and 1{Z_i != Z_j}.  The ordering of components in each row
    corresponds to the pair outcomes (1,1), (0,1), (1,0), (0,0), the same as the
    ordering of components in U. 

    NB: This function is specific to the moments used in our simulations.

    G = pairwise-stable network on N nodes.
    Pi = opportunity graph on N nodes.
    Z = N-vector of binary attributes.
    """
    output = np.zeros((2,4))
    for edge in Pi.Edges(): # only include pairs that are linked in Pi
        i = min(edge.GetSrcNId(), edge.GetDstNId())
        j = max(edge.GetSrcNId(), edge.GetDstNId())
        if i == j:
            raise ValueError('Error in gen_observed_moment: no self-links \
                    allowed.')

        cfriend = snap.GetCmnNbrs(G, i, j) > 0 # 1{# common friends > 0}
        if G.IsEdge(i,j):
            if Z[i] == Z[j]:
                if cfriend:
                    output[0,0] += 1 # transitive triad
                else:
                    output[0,2] += 1 # linked, no common friends
            else:
                if cfriend:
                    output[1,0] += 1
                else:
                    output[1,2] += 1
        else:
            if Z[i] == Z[j]:
                if cfriend:
                    output[0,1] += 1 # intransitive triad
                else:
                    output[0,3] += 1 # unlinked, no common friends
            else:
                if cfriend:
                    output[1,1] += 1
                else:
                    output[1,3] += 1
 
    return output / float(Z.shape[0])

def gen_model_moment(Pi, Z, theta):
    """
    Implements estimator (28).
    
    Returns 2x4 matrix, where each row is the 1x4 vector corresponding to each
    of the conditional probabilities in Example 19.  The first row corresponds
    to the instrument 1{Z_i = Z_j}, the second row to 1{Z_i != Z_j}.

    NB: This function is specific to the moments and joint surplus function used
    in our simulations. 

    Pi = opportunity graph.
    Z = N-vector of binary attributes.
    theta = true parameter vector.
    """
    output = np.zeros((2,4))
    sigma = math.sqrt(theta[3])
    
    for edge in Pi.Edges(): # restriction ||i-j|| \leq r_n
        i = min(edge.GetSrcNId(), edge.GetDstNId())
        j = max(edge.GetSrcNId(), edge.GetDstNId())
        if i == j:
            raise ValueError('Error in gen_model_moment: i = j')

        V_exo = theta[0]/sigma + (Z[i] != Z[j]) * theta[1]/sigma
        norm_V_exo = norm.cdf(V_exo)
        norm_V_all = norm.cdf(V_exo + theta[2]/sigma)
        
        if theta[2] > 0:
            if Z[i] == Z[j]: # instrument: 1{Z_i = Z_j}
                output[0,0] += norm_V_exo # conditional probability multiplying max{u_1,u_3}
                output[0,1] += norm_V_all - norm_V_exo # max{u_1,u_4}
                output[0,3] += 1 - norm_V_all # max{u_2,u_4}
            else: # instrument: 1{Z_i != Z_j}
                output[1,0] += norm_V_exo
                output[1,1] += norm_V_all - norm_V_exo
                output[1,3] += 1 - norm_V_all
        else:
            if Z[i] == Z[j]:
                output[0,0] += norm_V_all
                output[0,2] += norm_V_exo - norm_V_all # max{u_2,u_3}
                output[0,3] += 1 - norm_V_exo
            else:
                output[1,0] += norm_V_all
                output[1,2] += norm_V_exo - norm_V_all
                output[1,3] += 1 - norm_V_exo
 
    return output / float(Z.shape[0])

def gen_moments(observed_M, model_M, U):
    """
    Returns array of moments with dimension |U| * # instruments. Each element
    corresponds to the estimator \hat m_n(\theta; u, h) defined in the Monte
    Carlo section.

    observed_M = output of observed_moment().
    model_M = output of model_moment().
    U = values in \mathcal{U} to use for generating moments. Dimension must be p
    x 4, where p is any integer. Theorem 2 suggests to use the set of canonical
    basis vectors.
    """
    output = np.zeros((2,U.shape[0]))
 
    for i in range(2): # instruments. i=0: 1{Z_i = Z_j}. i=1: 1{Z_i != Z_j}
        for u in range(U.shape[0]):
            output[i,u] = np.dot(U[u,:], observed_M[i,:]) \
                    - max(U[u,0], U[u,2]) * model_M[i,0] \
                    - max(U[u,0], U[u,3]) * model_M[i,1] \
                    - max(U[u,1], U[u,2]) * model_M[i,2] \
                    - max(U[u,1], U[u,3]) * model_M[i,3]
    
    return np.hstack((output[0,:], output[1,:]))

def grid_search(G, Pi, Z, m):
    """
    Returns a triplet:
    observed_moment = output of gen_observed_moment().
    model_moments_grid = output of gen_model_moment() for all parameters in
    desired grid.
    id_set = estimate of identified set.

    G = pairwise-stable network on N nodes.
    Pi = opportunity graph on N nodes.
    theta = true parameter.
    m = grid the step size in each dimension (divided by two, rounded up, in
    variance dimension).
    """
    N = Z.shape[0]
    k = complex(0,m)

    theta_grid = np.mgrid[-1:1:k, -1:1:k, \
            -1:1:k, 0:1:complex(0,m/2+1)].reshape(4,-1).T # 11x11x11x6
    # can't have zero variance
    theta_grid[:,3] += np.tile([0.0001, 0.0, 0.0, 0.0, 0.0, 0.0], m**3)
    tot = theta_grid.shape[0]
    
    # values in \mathcal{U} to use for generating moments
    U = np.mgrid[0:2:1, 0:2:1, 0:2:1, 0:2:1].reshape(4,-1).T

    moments_grid = np.zeros((tot,U.shape[0]*2)) # values of moments for each theta
    model_moments_grid = np.zeros((tot,8))

    observed_moment = gen_observed_moment(G, Pi, Z)
    
    for t in range(tot):
        if t < 2:
            t0 = time.clock()
        
        model_moment = gen_model_moment(Pi, Z, theta_grid[t,:])
        model_moments_grid[t,:] = np.hstack((model_moment[0,:], \
                model_moment[1,:]))
        moments_grid[t,:] = gen_moments(observed_moment, model_moment, U)
        
        if t < 2:
            print "  t = %d of %d" % (t, tot)
            print moments_grid[t,0:30]
            t1 = time.clock()
            print "    Time elapsed: %s" % (t1-t0)
     
    # CHT objective function for each parameter
    Q_grid = np.sum(np.square(np.maximum(moments_grid, 0)),1)
    
    id_set = theta_grid[Q_grid < math.log(N)/N * 0.0001,:]
   
    return (observed_moment, model_moments_grid, id_set)

